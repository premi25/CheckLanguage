import dash
import base64
import dash_bootstrap_components as dbc
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import pandas as pd
from temp import StatisticHandler,TextHandler,StatisticNotAddedError

#----------------Define Variables and Const----------------------------------------------------------------
cssStylesheets = ['background.css']
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
app.css.append_css({"external_url": "/assets/{}".format(cssStylesheets)})
stat = StatisticHandler()
textAnalizer=TextHandler(stat)



navbar = dbc.NavbarSimple(
    brand="Dash language analyzer",
    sticky="top",
    color="dark",
    dark=True,)
app.config['suppress_callback_exceptions']=True
AnaliseBoolSucces = True
showMessageStat = False
#stat.addStatistic(pd.read_json('TurkishA.json', orient='columns',encoding = "utf-8"),'TurkishA.json')
analizedLenguage ='null'
def change_analizedLenguage(value):
    global analizedLenguage
    analizedLenguage = value

def read_analizedLenguage():
    return analizedLenguage

df_analizedText = {}
def change_df_analizedText(value):
    global df_analizedText
    df_analizedText = value
def read_df_analizedText():
    return df_analizedText

addedLanguage ='null'
def change_addedLanguage(value):
    global addedLanguage 
    addedLanguage = value
def read_addedLanguage():
    return addedLanguage

StatDictALL=stat.getStatDict()
StatDictAver=stat.getAveregeDict()
df_text = {} #text.getTextStatistic()


#--------------------############-----FileReadFunc--------################--------------------------
#-------------------------------------Statistics----------################--------------------------
dataframe = {}

def getDataframe():
    global dataframe
    return dataframe

def setDataframe(value):
    global dataframe
    dataframe = value
    
def parse_contents(contents, filename):
    try:        
        if 'json' in filename:
            df = pd.read_json(filename, orient='columns',encoding = "utf-8")
            return df
    except Exception as e:
        print(e)
        return html.Div(['There was an error processing this file.'])
    
    
    
    
#--------------------------MAIN BAR AREA-----------------------------------------------------------------------------
card = dbc.Card(
    [
        dbc.CardHeader(
            dbc.Tabs(
                [
                    dbc.Tab(label="Analysis", tab_id="analysisTab"),
                    dbc.Tab(label="Statistics", tab_id="statisticsTab"),
                ],
                id="card-tabs",
                card=True,
                active_tab="statisticsTab",
            )
        ),
        dbc.CardBody(
                html.P(id="card-content")),
    ]
)
             
#------------------------#################### Analyse Text Layout #####################-------------------------------------     
AnalyseTextLayout = html.Div([
#-------------Upload----------------------------------- 
       html.Div([
        html.Div(id='output-data-upload2',style = {'text-align':'center','colore':'green'}),
                 dcc.Upload(
                        id='upload-data2',
                        children=html.Div([
                                'Drag and Drop text to analyze or ',
                                html.A('Select Files')
                                ]),
            style={
                    'width': '100%',
                    'height': '60px',
                    'lineHeight': '60px',
                    'borderWidth': '1px',
                    'borderStyle': 'dashed',
                    'borderRadius': '5px',
                    'textAlign': 'center'
                    },
                    multiple=False,
                    accept=".txt"
                    ),
            
            ],
            className="mt-4",
            ),

#------------------------CONFIG----------------------------------------- 
     html.Div(id = 'message2',children = [],style = {'color':'red','text-align':'center','text-size':20,'margin-top':10,}
         ),
 html.Div([
#------------------------TITEL----------------------------------------- 
        
       dbc.Col([
              
         
         html.Div(['Dash Configuration'],style = {'alige':'center','margin-top':10,'margin-right':10}
         ),          
#------------------------1 DROPDOWN-----------------------------------------      
       html.Div(['Choose statistic:'],style = {'margin-top':10,'margin-left':10,'margin-right':30}
               ),             
       html.Div(
               dcc.Dropdown(id='opt-dropdown2',options=[],value = ''),style ={'alige':'center','width':170,'margin-top':10,'margin-left':10,'margin-right':10}
               )
       ],style ={'alige':'center','height':125,'margin-top':10,'width':'96%','margin-left':20,'margin-right':10,'max-width':50000,'border-style':'solid','border-radius':10}
      )],style = {'alige':'center'}),
##------------------------GRAPH-----------------------------------------   
   html.Div([dcc.Graph(id ='example-graph2',)],
                        style = {'alige':'center','hight':200,'width':'98%','margin-left':10,'margin-right':10,'margin-top':10,'max-width':50000,'border-style':'solid','border-radius':10}),
#------------------------TABLE-----------------------------------------   
html.H5(['Statistic table'],style ={'align':'center','text-align':'center','margin-bottom':3,'margin-top':10,'margin-left':10,'margin-right':10
                    }),
    
   html.Div(id='output_table2',children=[],style = {'width':'98%', 'overflow-x': 'scroll'})
#----------------------------Analyse Text Layout Div End--------------
        ])
                        
                                     
                        
                        
                        
#-------------------------------##################### Statistic Layout #####################------------------------------------     
StatisticLayout = html.Div([
#-------------Upload-----------------------------------
    html.Div([
    html.Div(id='output-data-upload',style = {'text-align':'center','color':'green'}),
    dcc.Upload(
        id='upload-data',
        children=html.Div([
            'Drag and Drop statistic or ',
            html.A('Select Files')
        ]),
        style={
            'width': '100%',
            'height': '60px',
            'lineHeight': '60px',
            'borderWidth': '1px',
            'borderStyle': 'dashed',
            'borderRadius': '5px',
            'textAlign': 'center'
        },
        multiple=False,
        accept=".json"
        )
        
        ],
        className="mt-4",
        ),

   
   html.Div(id = 'message',children = [],style = {'color':'red','text-align':'center','text-size':20}),  
 html.Div([
#------------------------TITEL----------------------------------------- 
        html.Div(['Dash Configuration'],style = {'text-align':'center','margin-top':10,'margin-right':10}
         ),
#------------------------1 DROPDOWN-----------------------------------------               
        
       dbc.Row(
    [
        dbc.Col(
              html.Div(['Choose language:']),style ={'width':120,'margin-bottom':10,'margin-top':10,'margin-left':35,'margin-right':10
                    }
        ),
        dbc.Col(
              html.Div(['Choose statistic:']),style ={'width':120,'margin-top':10,'margin-left':10,'margin-right':20})
               
               ]
        )  ,      
        
       dbc.Row(
    [
        dbc.Col(
                html.Div([
                dcc.Dropdown(
                            id = 'language_dropdown',
                            options=[
                                    {'label': 'Turkish', 'value': 'Turkish'},
                                    {'label': 'Swedish', 'value': 'Swedish'},
                                    {'label': 'Ukrainian', 'value': 'Ukrainian'},
                                    {'label': 'Italian', 'value': 'Italian'}
                                    ],
                            value=' ',style ={'width':150})
                    ]),style ={'width':50,'margin-bottom':10,'margin-top':10,'margin-left':35,'margin-right':10
                    }
        ),
        dbc.Col(
                html.Div([ 
           dcc.Dropdown(id='opt-dropdown',value = ' ',style ={'width':150})
                  ]),style ={'width':50,'margin-top':10,'margin-left':10,'margin-right':20})
      ]
            )
        ],style ={'alige':'center','height':150,'margin-top':10,'width':'96%','margin-left':20,'margin-right':10,'max-width':50000,'border-style':'solid','border-radius':10,'background-color':'#F5F5F5'}
     ),
               
        
        
                    
#------------------------GRAPH-----------------------------------------   
        
        html.Div([dcc.Graph(id ='example-graph',)],
                        style = {'hight':200,'width':'98%','margin-left':10,'margin-right':10,'margin-top':10,'max-width':50000,'border-style':'solid','border-radius':10,'background-color':'#F5F5F5'}),
     
#------------------------TABLE-----------------------------------------   
        html.H5(['Statistic table'],style ={'align':'center','text-align':'center','margin-bottom':3,'margin-top':10,'margin-left':10,'margin-right':10
                    }),
        html.Div(id='output_table',children=[],style = {'width':'98%', 'overflow-x': 'scroll'})
#----------------------------Statistic Layout Div End--------------
        ])
                    
                    
    
    
                    
                    
#----------------------------MAIN PAGE---------------------------------------------------------------------------     
             
app.layout = html.Div([navbar,card])

#------------------############## Call backs AREA###################---------------------------------------------

#--------------##################-AnalyseTextCalls-###########################-----------------------------------
#@app.callback(
#        Output('message2','children')
#,[Input('button2','value')])
#def message_show2(name):
#    if name in StatDictALL:
#       return 'The analised language is: {}'.format(name)
#    else: return 'Faild to analize the language'  
##------------------------------------------------------------



@app.callback(
    dash.dependencies.Output('example-graph2', 'figure'),
    [dash.dependencies.Input('opt-dropdown2','value')])
def stats_int2(opt_language):
    x = []
    y = []
    global df_text
    global StatDictAver
    global StatDictALL
    if read_analizedLenguage() in StatDictALL:
        if opt_language == 'Average':           
            x=StatDictAver[read_analizedLenguage()].columns
            k=StatDictAver[read_analizedLenguage()].iloc[0]
            for i in k:
                y.append(i)
        elif opt_language == 'TextStatistic':     
            x=df_text.columns
            k=df_text.iloc[0]
            for i in k:
                y.append(i)                   
        else:
            x=StatDictALL[read_analizedLenguage()][opt_language-1].columns
            k=StatDictALL[read_analizedLenguage()][opt_language-1].iloc[0]
            for i in k:
                y.append(i)
        return {
                    'data': [ {'x': x , 'y': y, 'type':'line', 'name': 'text'}
                    ],
                    'layout': {'title': '{}'.format(read_analizedLenguage())}
                    }
    else: return {
                'data': [ {'x': x , 'y': y, 'type':'line', 'name': 'text'}
                ],
                'layout': {'title': 'No graph info for this language'}
                }
        
                
@app.callback(
     Output('opt-dropdown2','options'),
     [Input('message2','children')])
def update_dropdown2(value):
    options = []
    global StatDictALL
    global AnaliseBoolSucces
    if AnaliseBoolSucces == True:
        if read_analizedLenguage() in StatDictALL:
            options.append({'label': 'Text Statistic', 'value':'TextStatistic'})
            options.append({'label': 'Average', 'value':'Average'}),
            for i in range(len(StatDictALL[read_analizedLenguage()])):
                options.append({'label': i+1, 'value': i+1})
        else:options.append({'label': 'No value', 'value': 0})
    return options

@app.callback(
     Output('opt-dropdown2','value'),
     [Input('message2','children')])
def update_dropdown2_value(value):
    global AnaliseBoolSucces
    if AnaliseBoolSucces == True:
        return 'TextStatistic'


@app.callback(
    dash.dependencies.Output('output_table2', 'children'),
    [dash.dependencies.Input('opt-dropdown2','value')]
    )
def table_print2(value):
    global StatDictALL
    global AnaliseBoolSucces
    if AnaliseBoolSucces == True:
        df = read_df_analizedText()
        return html.Table(
# Header
        [html.Tr([html.Th(col, style = {'text-align':'center','border': '2px solid black','padding':'0px 25px 0px 25px','background-color':'silver'}) for col in df.columns])] +

# Body
        [html.Tr([
                html.Td(df.iloc[i][col], style = {'text-align':'center','border': '2px solid black','padding':'0px 25px 0px 25px','background-color':'silver'}) for col in df.columns
                ]) for i in range(df.index.max()+1)]
        ,style = {'border-radius':10,'border': '3px solid black','margin':10,'margin-top':20})
    else:
        return html.Div(['No info to build a table'],style = {'text-align':'center'})
    
@app.callback(Output('message2','children'),
              [Input('upload-data2', 'contents')],
              [State('upload-data2', 'filename')])
def update_output2(content, name): 
    global textAnalizer
    global df_text
    global StatDictALL
    global StatDictAver
    global stat
    global AnaliseBoolSucces
    if content is not None:
        try:
             decoded = base64.b64decode(content)
             decoded2 = decoded.decode('utf-8','ignore')
             text = textAnalizer.analyzeText(decoded2[6:])
             df_text = text.getTextStatistic()
             change_analizedLenguage(text.getLanguage())
             change_df_analizedText(text.getStatisticTable())
             StatDictALL=stat.getStatDict()
             StatDictAver=stat.getAveregeDict()
             if read_analizedLenguage() in StatDictALL:
                 AnaliseBoolSucces = True                 
                 return 'The analised language is: {}'.format(text.getLanguage())
             else:
                 AnaliseBoolSucces = False
                 return 'Error analizing text. Check if all statistics are added.'.format(text.getLanguage())
        except StatisticNotAddedError as err:
             change_analizedLenguage(' ')
             AnaliseBoolSucces = False
             return 'Error analizing text. Check if all statistics are added. '.format(err.getMessage())
        except ZeroDivisionError:
            change_analizedLenguage(' ')
            AnaliseBoolSucces = False
            return 'Error analizing text. Check if all statistics are added. '



#---------------##############################----StatisticCalls------#############################----------------------------------------------------------------------------------------     
@app.callback(
        Output('message','children')
        ,[Input('language_dropdown','value')])
def message_show(name):
    global StatDictALL
    if len(StatDictALL[name]) == 0:
       return 'Warning! Statistic has not been added!!! Please add statistic.'

@app.callback(
    dash.dependencies.Output('example-graph', 'figure'),
    [dash.dependencies.Input('language_dropdown', 'value'),
    dash.dependencies.Input('opt-dropdown','value')])
def stats_int(main_language,opt_language):
    x = []
    y = []
    global StatDictALL
    global StatDictAver
    if len(StatDictALL[main_language]) > 0:   
        
        if main_language in StatDictALL:
            if opt_language == 'Average':            
                x=StatDictAver[main_language].columns
                k=StatDictAver[main_language].iloc[0]
                for i in k:
                    y.append(i)
            else:
                x=StatDictALL[main_language][opt_language-1].columns
                k=StatDictALL[main_language][opt_language-1].iloc[0]
                for i in k:
                    y.append(i)
        return {
                'data': [ {'x': x , 'y': y, 'type':'line', 'name': 'text'}
                ],
                'layout': {'title': '{} {}'.format(main_language,opt_language)}
                }
    else: return {
            'data': [ {'x': x , 'y': y, 'type':'line', 'name': 'text'}
                ],
            'layout': {'title': 'No graph info for this language'}
            }


@app.callback(Output('output-data-upload', 'children'),
              [Input('language_dropdown', 'value'),
              Input('opt-dropdown', 'value')])
def massege_setup(list_of_contents, name):
    global showMessageStat 
    if showMessageStat == False:
        return ' '
    else:
        return 'Statistic for {} language added.'.format(read_addedLanguage())
                
@app.callback(
     Output('opt-dropdown','options'),
     [Input('language_dropdown','value')])
def update_date_dropdown(name):
    options = []
    global StatDictALL
    if len(StatDictALL[name]) > 0:
        options.append({'label': 'Average', 'value': 'Average'})
        for i in range(len(StatDictALL[name])):
            options.append({'label': i+1, 'value': i+1})
    
    else:options.append({'label': 'No value', 'value': 0})
    return options

@app.callback(
     Output('opt-dropdown','value'),
     [Input('language_dropdown','value'),
      Input('opt-dropdown','options')])
def opt_value(name,val):
    global StatDictALL
    if len(StatDictALL[name]) == 0:
        return 'No value'
    else: return 'Average'

@app.callback(
    dash.dependencies.Output('output_table', 'children'),
    [dash.dependencies.Input('language_dropdown', 'value')])
def table_print(language):
    global stat
    global StatDictALL
    global showMessageStat
    if len(StatDictALL[language]) > 0:
         df = stat.getStatisticTable(language) 
         showMessageStat = False
         return html.Table(
# Header
        [html.Tr([html.Th(col, style = {'text-align':'center','border': '2px solid black','padding':'5px 25px 5px 25px','background-color':'silver'}) for col in df.columns])] +

# Body
        [html.Tr([
                html.Td(df.iloc[i][col], style = {'text-align':'center','border': '2px solid black','padding':'5px 25px 5px 25px','background-color':'silver','text-font':12}) for col in df.columns
                ]) for i in range(df.index.max()+1)]
        , style = {'border-radius':10,'border': '3px solid black','margin':10,'margin-top':20}
        )
    else:
        return html.Div(['No info to build a table'],style = {'text-align':'center'})


@app.callback(Output('language_dropdown','value'),
              [Input('upload-data', 'contents')],
              [State('upload-data', 'filename')])
def update_output(list_of_contents, name):
    global stat
    global StatDictALL
    global StatDictAver
    global showMessageStat     
    if list_of_contents is not None:
       stat.addStatistic(parse_contents(list_of_contents, name), name)
       change_addedLanguage(stat.getLenguageName(name))
       showMessageStat = True
       return read_addedLanguage()


############### PAGE CHOOSER CALL #####################
@app.callback(
        Output("card-content", "children"),
        [Input("card-tabs", "active_tab")]
        )
def tab_content(active_tab):
    if active_tab == 'analysisTab' :
        return AnalyseTextLayout
    elif active_tab == 'statisticsTab' :
        return StatisticLayout

if __name__ == "__main__":
    app.run_server()