# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import pandas as pd
import copy

class Text:
    
    def __init__(self,language,df,statisticHandler):
        self.__language=language
        self.__stData=df
        self.__statisticHandler=statisticHandler
    
    def getLanguage(self):
        return self.__language
    
    def getTextStatistic(self):
        return self.__stData
    
    def getStatisticTable(self):
        df=self.__statisticHandler.getStatisticTable(self.__language)
        index=df.index.max()+1
        df.loc[index]=0
        df['Index'].loc[index]='Text Statistic'
        for char in df.columns:
            if char in self.__stData:  
                df[char].loc[index]=round(self.__stData[char].loc[0],2)
        return df        
        

class StatisticHandler:

    
    def __init__(self):
        pd.set_option('display.max_columns',200)
        self.__statDict={'Polish':[],'English':[],'German':[],'French':[],
                       'Spanish':[],'Italian':[],'Norway':[],'Ukrainian':[],
                       'Hungarian':[],'Denmark':[],'Swedish':[],'Finnish':[],
                       'Russian':[],'Czech':[],'Slovak':[],'Turkish':[]}
        self.__averageDict={}
         
        
        
#    def __checkFileFormat(self,fileName):
#        if ".json" in fileName:
#            return pd.read_json(fileName, orient='columns',encoding = "utf-8")
#        elif ".csv" in fileName:
#            return pd.read_csv(fileName, orient='columns',encoding = "utf-8")
    
    def getLenguageName(self,fileName):
        for i in self.__statDict:
            if i in fileName:
                return i
            
    def __setAverageStat(self,langugeName):
        if langugeName not in self.__averageDict:
            self.__averageDict[langugeName]=copy.copy(self.__statDict[langugeName][0])
            for i in  self.__averageDict[langugeName]:
                 self.__averageDict[langugeName][i][0]=round(self.__averageDict[langugeName][i][0],2)
        else:
            columns=[] 
            for i in self.__statDict[langugeName]:
                columns=list(set(columns+list(i.columns)))
            for i in  columns:
                temp=0
                for j in self.__statDict[langugeName]: 
                    if i in j:
                        temp+=j[i][0]
                self.__averageDict[langugeName][i]=round((temp/len(self.__statDict[langugeName])),2)
                
              
    def getStatisticTable(self,language):
        if language in self.__averageDict:
            df=copy.copy(self.__averageDict[language])
            df['Index']='Average'
            for singleStatIndex in range(len(self.__statDict[language])):
                df.loc[df.index.max()+1]=0
                df['Index'].loc[singleStatIndex+1]=singleStatIndex+1
                for char in df.columns:
                    if char in self.__statDict[language][singleStatIndex]:  
                        df[char].loc[singleStatIndex+1]=round(self.__statDict[language][singleStatIndex][char].loc[0],2)
            return df                    
    
    
    def addStatistic(self,pdFile,fileName):
        languageName=self.getLenguageName(fileName)
        self.__statDict[languageName].append(pdFile)
        self.__setAverageStat(languageName)
        return languageName
       
    def getStatDict(self):
        return  self.__statDict
    
   
    def getAveregeDict(self):
         return self.__averageDict

class StatisticNotAddedError(RuntimeError):
   def __init__(self, arg):
      self.__args = arg
   
   def getMessage(self):
        return repr(self.__args)
        
class TextHandler:
    
    def __init__(self,statisticHandler):
        self.__statisticHandler=statisticHandler
    

    def __definePredykantDict(self):
        self.__predykantDict={}
        for language in self.__statisticHandler.getStatDict():
            if language in self.__statisticHandler.getAveregeDict():
                predicantList=self.__statisticHandler.getAveregeDict()[language].columns
                for i in self.__statisticHandler.getAveregeDict():
                    if language!=i:
                        predicantList=predicantList.difference(self.__statisticHandler.getAveregeDict()[i].columns)
                self.__predykantDict[language]=predicantList
            else:
                self.__predykantDict[language]=[]
                
    def __createCombineHeaderDict(self):
        combinationList=[]
        combinationDict={}
        for i in self.__statisticHandler.getAveregeDict():
            combinationList=list(set(combinationList+list(self.__statisticHandler.getAveregeDict()[i].columns)))
        for i in combinationList:
            combinationDict[i]=0
        return combinationDict
        
#    def __readListOfCharacterFromFile(self,path):
#        with open(path,'r',encoding = "utf-8") as file:
#            return list(file.read())
        
    def __analyzeByStatistic(self,combinationDict): 
        simularityDict={}
        for language in self.__statisticHandler.getAveregeDict():
            simularityDict[language]=0
        for symbol in combinationDict:
            for language in self.__statisticHandler.getAveregeDict():
                if symbol in self.__statisticHandler.getAveregeDict()[language].columns:
                    simularityDict[language]+=abs(combinationDict[symbol]-self.__statisticHandler.getAveregeDict()[language][symbol][0])
                else:
                    simularityDict[language]+=combinationDict[symbol]
        return min(simularityDict, key=lambda k: simularityDict[k])
            
    def analyzeText(self,content):
        if len(self.__statisticHandler.getAveregeDict())==0:
            raise StatisticNotAddedError('Please add statistic before analysis')
        self.__definePredykantDict()
        combinationDict=self.__createCombineHeaderDict()
        resultLanguage="undefined"
        numerOfCharacters=0
        charList=list(content)
        #moving throught list of symbols from text
        for charFromFile in charList:
            #check if symbol is predycant
            if resultLanguage=="undefined":
                for language in self.__predykantDict:
                    if charFromFile in self.__predykantDict[language]:
                        resultLanguage=language
                    
            #calculate number of symbols from combinationDict in text ond full number of symbols in text
            if charFromFile in combinationDict:
                combinationDict[charFromFile]+=1
                numerOfCharacters+=1
                
                    
        #calculate ratio
        for i in combinationDict:
            combinationDict[i]=(combinationDict[i]/numerOfCharacters)*100
        
        if resultLanguage=="undefined":
            print('combinationDict:', combinationDict)
            resultLanguage=self.__analyzeByStatistic(combinationDict)
       
       
              
        return Text(resultLanguage,pd.DataFrame(combinationDict,index=[0])[self.__statisticHandler.getAveregeDict()[resultLanguage].columns], self.__statisticHandler)